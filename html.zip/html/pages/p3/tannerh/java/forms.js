$(document).ready(function() {
	$("#item1").hide();
	$("#item1nav").click(function() {
		$("#item1").show();
	});
});
