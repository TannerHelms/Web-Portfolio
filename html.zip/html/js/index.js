displayDate();
function displayDate() {
    //DATE CLASS
    var d = new Date();
    //24 hour version...just for AM and PM
    var TwentyFourHour = d.getHours();
    //month
    var month = d.getMonth();
    //day
    var dayNumber = d.getDate();
    var day = d.getDay();
    //year
    var year = d.getFullYear();
    //hours
    var hour = d.getHours();
    //minutes
    var min = d.getMinutes();
    //seconds
    var sec = d.getSeconds();
    // PM or AM
    var mid = "PM";
    //
    var dayArrayNumber = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
    //Array for days
    var dayArray = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    //Array for months
    var monthArray = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    //if minutes are less than 10 then add 0 in front of the number
    if (min < 10) {
        min = "0" + min;
    }
    //if seconds are less than 10 then add 0 in front of the number
    if (sec < 10) {
        sec = "0" + sec;
    }
    //if hours are greater than 12 then subtract 12. ex= 14-12=2
    if (hour > 12) {
        hour = hour - 12;
    }
    //if hour is 00:00 make it 12:00
    if (hour == 0) {
        hour = 12;
    }
    //if it is less than 12 then it is AM
    if (TwentyFourHour < 12) {
        mid = "AM";
    }
    //console.log("Today's date -> " + d.getDate());
    //displaying the clock
    document.getElementById("date").innerHTML = " " + dayArrayNumber[dayNumber - 1] + " " + monthArray[month] + " " + year;
    document.getElementById("time").innerHTML = hour + ":" + min + ":" + sec + " " + mid;
    setTimeout(displayDate, 1000);
}

function findFactorial(event) {
    if (event.key == "Enter") {
        var x = document.getElementById("factorial").value;
        var fac = findingFactorial(x);
        document.getElementById("ansFactorial").innerHTML = "The Factorial for " + x + " is " + fac;
    }
}
function findingFactorial(x) {
    if (x == 0 || x == 1) {
        return 1
    } else {
        return x * findingFactorial(x - 1);
    }
}
function findQuad() {
    var A = document.getElementById("quadA").value;
    var B = document.getElementById("quadB").value;
    var C = document.getElementById("quadC").value;
    var determinate = B * B - 4 * A * C;



    if (determinate > 0) {
        document.getElementById("ansQuad").innerHTML = "There are two roots for the quadratic equation with these coefficients.";
        document.getElementById("ans2Quad").innerHTML = "r1 = " + (-B + Math.pow(determinate, 0.5)) / (2 * A) + "<br>r2 =  " + (-B - Math.pow(determinate, 0.5)) / (2 * A);
    } else if (determinate < 0) {
        document.getElementById("ansQuad").innerHTML = "There are no real roots for the quadratic equation with these coefficients.";

    } else {
        document.getElementById("ansQuad").innerHTML = "There is one real root for the quadratic equation with these coefficients.";
        document.getElementById("ans2Quad").innerHTML = "r1 = " + -B / 2 * A;
    }

}
function calcRadius() {
    var radius = document.getElementById("radiusCircle").value;
    document.getElementById("radiusText").innerHTML = "Radius: " + radius + "<br>Area: " + Math.PI * radius * radius + "<br>Diameter: " + (radius * 2) * Math.PI;
}
function calcArea() {
    var side1 = document.getElementById("side1Rectangle").value;
    var side2 = document.getElementById("side2Rectangle").value;
    document.getElementById("rectangleText").innerHTML = "Side 1: " + side1 + "<br>Side 2: " + side2 + "<br>Area: " + side1 * side2;
}
function buildPyramid(event) {
    var rows = document.getElementById("pyramidRows").value;
    var pyramid = "";
    if (event.key == "Enter") {
        for (var i = 1; i <= rows; i++) {
            for (var j = 1; j <= (rows - i) * 2; j++) {
                pyramid += " ";
            }
            for (var k = i; k >= 1; k--) {
                pyramid += " " + k;
            }
            for (var p = 2; p <= i; p++) {
                pyramid += " " + p;
            }
            pyramid += "<br>";
        }
    }
    document.getElementById("demopyramid").innerHTML = pyramid;
}
function changeOrganismCcolor(id) {
    if (document.getElementById(id).style.backgroundColor == "red") {
        document.getElementById(id).style.backgroundColor = "rgba(255, 255, 255, 0.8)";
        if (id == "color1") {
            organismArray[0][0] = "_";
            console.log(organismArray);
        }
        if (id == "color2") {
            organismArray[0][1] = "_";
            console.log(organismArray);
        }
        if (id == "color3") {
            organismArray[0][2] = "_";
            console.log(organismArray);
        }
        if (id == "color4") {
            organismArray[1][0] = "_";
            console.log(organismArray);
        }
        if (id == "color5") {
            organismArray[1][1] = "_";
            console.log(organismArray);
        }
        if (id == "color6") {
            organismArray[1][2] = "_";
            console.log(organismArray);
        }
        if (id == "color7") {
            organismArray[2][0] = "_";
            console.log(organismArray);
        }
        if (id == "color8") {
            organismArray[2][1] = "_";
            console.log(organismArray);
        }
        if (id == "color9") {
            organismArray[2][2] = "_";
            console.log(organismArray);
        }
    } else {
        document.getElementById(id).style.backgroundColor = "red";
        if (id == "color1") {
            organismArray[0][0] = "*";
            console.log(organismArray);
        }
        if (id == "color2") {
            organismArray[0][1] = "*";
            console.log(organismArray);
        }
        if (id == "color3") {
            organismArray[0][2] = "*";
            console.log(organismArray);
        }
        if (id == "color4") {
            organismArray[1][0] = "*";
            console.log(organismArray);
        }
        if (id == "color5") {
            organismArray[1][1] = "*";
            console.log(organismArray);
        }
        if (id == "color6") {
            organismArray[1][2] = "*";
            console.log(organismArray);
        }
        if (id == "color7") {
            organismArray[2][0] = "*";
            console.log(organismArray);
        }
        if (id == "color8") {
            organismArray[2][1] = "*";
            console.log(organismArray);
        }
        if (id == "color9") {
            organismArray[2][2] = "*";
            console.log(organismArray);
        }
    }
}
var organismArray = [
    ["_", "_", "_"],
    ["_", "_", "_"],
    ["_", "_", "_"]

];
function drawOrganism() {
    let letter = 65;
    var Organisms = 0;
    for (var col = 0; col <= organismArray.length - 1; col++) {
        for (var row = 0; row <= organismArray[col].length - 1; row++) {
            if (organismArray[col][row] == "*") {
                organismArray = howManyOrganisms(col, row, String.fromCharCode(letter));
                letter++;
                Organisms++;
            }
        }
    }
    var printorganism = "";
    for (var i = 0; i <= organismArray.length - 1; i++) {
        for (var j = 0; j <= organismArray[i].length - 1; j++) {
            printorganism += organismArray[i][j];
        }
        printorganism += "<br>";
    }
    if (Organisms == 1) {
        document.getElementById("drawOrganism1").innerHTML = printorganism + "<br>There is " + Organisms + " organism.";
    } else {
        document.getElementById("drawOrganism1").innerHTML = printorganism + "<br>There are " + Organisms + " organisms.";
    }

}

function howManyOrganisms(col, row, letter) {
    console.log("working");
    organismArray[col][row] = letter;


    if (col + 1 <= organismArray.length - 1) {
        if (organismArray[col + 1][row] == "*") {
            howManyOrganisms(col + 1, row, letter);
        }
    }
    if (col - 1 >= 0) {
        if (organismArray[col - 1][row] == "*") {
            howManyOrganisms(col - 1, row, letter);
        }
    }
    if (row - 1 >= 0) {
        if (organismArray[col][row - 1] == "*") {
            howManyOrganisms(col, row - 1, letter);
        }
    }
    if (row + 1 <= organismArray[col].length - 1) {
        if (organismArray[col][row + 1] == "*") {
            howManyOrganisms(col, row + 1, letter);
        }
    }
    return organismArray;
}


function findDerivitive(event) {
    if (event.key == "Enter") {
        var der = document.getElementById("enterDerivitive").value;
        draw();
        var result = nerdamer("diff(" + der + ",x)").evaluate();
        der = result;
        document.getElementById('thederiv').innerHTML = "<p>f'(x)=" + result.text() + '</p>';
        event.preventDefault();
        draw();

    }
}


function draw() {
    try {
      // compile the expression once
      const expression = document.getElementById('enterDerivitive').value;
      const expr = math.compile(expression)

      // evaluate the expression repeatedly for different values of x
      const xValues = math.range(-10, 10, 0.5).toArray()
      const yValues = xValues.map(function (x) {
        return expr.evaluate({x: x})
      })

      // render the plot using plotly
      const trace1 = {
        x: xValues,
        y: yValues,
        type: 'scatter'
      }
      const data = [trace1]
      Plotly.newPlot('plot1', data)
    }
    catch (err) {
      console.error(err)
      alert(err)
    }
  }
  function draw1() {
    try {
      // compile the expression once
      const expression = document.getElementById('enterDerivitive').value;
      const expr = math.compile(expression)

      // evaluate the expression repeatedly for different values of x
      const xValues = math.range(-10, 10, 0.5).toArray()
      const yValues = xValues.map(function (x) {
        return expr.evaluate({x: x})
      })

      // render the plot using plotly
      const trace1 = {
        x: xValues,
        y: yValues,
        type: 'scatter'
      }
      const data = [trace1]
      Plotly.newPlot('plot1', data)
    }
    catch (err) {
      console.error(err)
      alert(err)
    }
  }

  

  draw()