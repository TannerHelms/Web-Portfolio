#!/bin/bash
clear
echo "Hello, welcome to my BASH addition experiment program!"
x=$1
y=$2

echo The sum is $(($x+$y))
