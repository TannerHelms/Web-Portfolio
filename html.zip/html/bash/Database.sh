#!/bin/bash
clear
sudo apt-get update
sudo apt-get install mysql-server
sudo apt-get install mysql-workbench
sudo apt-get install phpmyadmin apache2-utils


